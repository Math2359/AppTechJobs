package com.techjobs.retrofit

import com.techjobs.service.CandidatoService
import com.techjobs.service.EmpresaService
import com.techjobs.service.LoginService
import com.techjobs.service.VagaService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitInitializer {
    private val retrofit =
        Retrofit.Builder().baseUrl("https://apitechjobs.onrender.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    val candidatoService: CandidatoService = retrofit.create(CandidatoService::class.java)

    val empresaService: EmpresaService = retrofit.create(EmpresaService::class.java)

    val loginService: LoginService = retrofit.create(LoginService::class.java)

    val vagaService: VagaService = retrofit.create(VagaService::class.java)
}