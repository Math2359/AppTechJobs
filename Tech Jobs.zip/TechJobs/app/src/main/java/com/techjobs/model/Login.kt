package com.techjobs.model

data class Login(
    val email: String,
    val senha: String
)
