package com.techjobs.service

import com.techjobs.model.Candidato
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

interface CandidatoService {
    @GET("candidato")
    fun obterCandidatos(): Call<Array<Candidato>>

    @Headers("Content-Type: application/json")
    @POST("candidato")
    fun cadastrarCandidato(@Body candidato: Candidato): Call<Void>
}