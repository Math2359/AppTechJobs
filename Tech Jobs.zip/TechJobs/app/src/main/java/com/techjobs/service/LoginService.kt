package com.techjobs.service

import com.techjobs.model.Empresa
import com.techjobs.model.Login
import com.techjobs.model.UserCredentials
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface LoginService {
    @POST("login")
    fun logar(@Body login: Login): Call<UserCredentials>
}