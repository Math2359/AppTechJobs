package com.techjobs

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.techjobs.helper.SessionHelper
import com.techjobs.model.Empresa
import com.techjobs.model.Vaga
import com.techjobs.retrofit.RetrofitInitializer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdicionarVagaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_adicionar_vaga)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val intent: Intent = Intent(this, DashboardEmpresaActivity::class.java)

        val btnVoltar: ImageView = findViewById(R.id.voltarBtn)
        btnVoltar.setOnClickListener {
            startActivity(intent)
        }

        val inputCargo: TextInputEditText = findViewById(R.id.inputCargo)
        val inputModelo: TextInputEditText = findViewById(R.id.inputModelo)
        val inputNivel: TextInputEditText = findViewById(R.id.inputNivel)
        val inputSalario: TextInputEditText = findViewById(R.id.inputSalario)
        val inputNumero: TextInputEditText = findViewById(R.id.inputNumero)
        val inputDescricao: TextInputEditText = findViewById(R.id.inputDescricao)
        val inputCep: TextInputEditText = findViewById(R.id.inputCep)

        inputCep.addTextChangedListener(object: TextWatcher {
            private var isUpdating = false
            private val mask = "#####-###"

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (isUpdating) return

                val unmasked = s.toString().replace(Regex("\\D"), "")
                val masked = StringBuilder()

                var index = 0
                for (char in mask) {
                    if (char == '#' && index < unmasked.length) {
                        masked.append(unmasked[index])
                        index++
                    } else if (index < unmasked.length) {
                        masked.append(char)
                    }
                }

                isUpdating = true
                inputCep.setText(masked.toString())
                inputCep.setSelection(masked.length)
                isUpdating = false
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        val btnAdicionar = findViewById<Button>(R.id.adicionarBtn)
        btnAdicionar.setOnClickListener {
            val vaga: Vaga = Vaga(
                empresa = Empresa(id = SessionHelper(this).obterUserCredentials().id),
                cep = inputCep.text.toString(),
                cargo = inputCargo.text.toString(),
                nivel = inputNivel.text.toString(),
                modelo = inputModelo.text.toString(),
                numero = inputNumero.text.toString(),
                salario = inputSalario.text.toString().toDouble(),
                descricao = inputDescricao.text.toString()
            )

            val call = RetrofitInitializer().vagaService.adicionarVaga(vaga)
            call.enqueue(object: Callback<Void> {
                override fun onResponse(call: Call<Void>,
                                        response: Response<Void>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@AdicionarVagaActivity,
                            "Vaga adicionada com sucesso",
                            Toast.LENGTH_LONG).show()
                        startActivity(intent)
                    }
                }

                override fun onFailure(call: Call<Void>, t: Throwable?) {
                    Toast.makeText(this@AdicionarVagaActivity, "Erro ao adicionar vaga",
                        Toast.LENGTH_LONG).show()
                }
            })
        }
    }
}