package com.techjobs.service

import com.techjobs.model.BuscaVagaParams
import com.techjobs.model.Vaga
import retrofit2.Call
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface VagaService {
    @GET("vaga/params")
    fun obterVagas(@Query("vaga") vaga: BuscaVagaParams? = null): Call<Array<Vaga>>

    @GET("vaga/empresa/{id}")
    fun obterVagasPorEmpresa(@Path("id") id: Int): Call<Array<Vaga>>

    @DELETE("vaga/{id}")
    fun deletarVaga(@Path("id") id: Int): Call<Void>
}