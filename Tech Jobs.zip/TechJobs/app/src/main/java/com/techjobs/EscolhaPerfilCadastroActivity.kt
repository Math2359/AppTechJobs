package com.techjobs

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class EscolhaPerfilCadastroActivity : AppCompatActivity() {
    private lateinit var btnCandidato: Button
    private lateinit var btnEmpresa: Button

    private lateinit var voltarBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_escolha_perfil_cadastro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        voltarBtn = findViewById<ImageView>(R.id.voltarBtn)
        voltarBtn.setOnClickListener {
            val intent: Intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        btnEmpresa = findViewById<Button>(R.id.btnEmpresa)
        btnEmpresa.setOnClickListener {
            val intent: Intent = Intent(this, CadastroEmpresaActivity::class.java)
            startActivity(intent)
        }

        btnCandidato = findViewById<Button>(R.id.btnCandidato)
        btnCandidato.setOnClickListener {
            val intent: Intent = Intent(this, CadastroCandidatoActivity::class.java)
            startActivity(intent)
        }
    }
}