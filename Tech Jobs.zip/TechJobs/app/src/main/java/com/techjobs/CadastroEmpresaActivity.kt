package com.techjobs

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.techjobs.model.Empresa
import com.techjobs.retrofit.RetrofitInitializer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroEmpresaActivity : AppCompatActivity() {
    private lateinit var voltarBtn: ImageView

    private lateinit var finalizarBtn: Button
    private lateinit var nomeInput: TextInputEditText
    private lateinit var emailInput: TextInputEditText
    private lateinit var senhaInput: TextInputEditText
    private lateinit var confirmarSenhaInput: TextInputEditText
    private lateinit var cnpjInput: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro_empresa)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        voltarBtn = findViewById<ImageView>(R.id.voltarBtn)
        voltarBtn.setOnClickListener {
            val intent: Intent = Intent(this, EscolhaPerfilCadastroActivity::class.java)
            startActivity(intent)
        }

        emailInput = findViewById<TextInputEditText>(R.id.inputEmail)
        nomeInput = findViewById<TextInputEditText>(R.id.inputNome)
        senhaInput = findViewById<TextInputEditText>(R.id.inputSenha)
        confirmarSenhaInput = findViewById<TextInputEditText>(R.id.inputConfirmarSenha)
        cnpjInput = findViewById<TextInputEditText>(R.id.inputCnpj)

        finalizarBtn = findViewById<Button>(R.id.finalizarBtn)

        finalizarBtn.setOnClickListener {
            val empresa: Empresa = Empresa(
                email = emailInput.text.toString(),
                nome = nomeInput.text.toString(),
                senha = senhaInput.text.toString(),
                cnpj = cnpjInput.text.toString())

            val call = RetrofitInitializer().empresaService.cadastrarEmpresa(empresa)
            call.enqueue(object: Callback<Void> {
                override fun onResponse(call: Call<Void>,
                                        response: Response<Void>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@CadastroEmpresaActivity,
                            "Cadastro realizado com sucesso",
                            Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<Void>, t: Throwable?) {
                    Toast.makeText(this@CadastroEmpresaActivity, "Erro ao realizar cadastro",
                        Toast.LENGTH_LONG).show()
                }
            })
        }

        cnpjInput.addTextChangedListener(object: TextWatcher {
            private var isUpdating = false
            private val mask = "##.###.###/####-##"

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (isUpdating) return

                val unmasked = s.toString().replace(Regex("\\D"), "")
                val masked = StringBuilder()

                var index = 0
                for (char in mask) {
                    if (char == '#' && index < unmasked.length) {
                        masked.append(unmasked[index])
                        index++
                    } else if (index < unmasked.length) {
                        masked.append(char)
                    }
                }

                isUpdating = true
                cnpjInput.setText(masked.toString())
                cnpjInput.setSelection(masked.length)
                isUpdating = false
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }
}