package com.techjobs.model

data class BuscaVagaParams(
    val cargo: String,
    val modelo: String,
    val nivel: String,
    val cep: String
)
