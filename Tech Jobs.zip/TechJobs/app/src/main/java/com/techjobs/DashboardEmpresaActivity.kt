package com.techjobs

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.techjobs.DashboardCandidatoActivity
import com.techjobs.adapters.VagasAdapter
import com.techjobs.helper.SessionHelper
import com.techjobs.model.Vaga
import com.techjobs.retrofit.RetrofitInitializer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashboardEmpresaActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dashboard_empresa)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        recyclerView = findViewById<RecyclerView>(R.id.recyclerVaga)
        obterVagas()
        recyclerView.layoutManager = LinearLayoutManager(this)

    }

    fun obterVagas() {
        val call = RetrofitInitializer().vagaService.obterVagasPorEmpresa(SessionHelper(this)
            .obterUserCredentials().id)

        call.enqueue(object: Callback<Array<Vaga>?> {
            override fun onResponse(call: Call<Array<Vaga>?>?,
                                    response: Response<Array<Vaga>?>) {
                if (response.isSuccessful) {
                    val vagas = response.body()?:emptyArray()

                    val customAdapter = VagasAdapter(vagas)

                    recyclerView.adapter = customAdapter
                }
            }

            override fun onFailure(call: Call<Array<Vaga>?>?,t: Throwable?) {
                Toast.makeText(this@DashboardEmpresaActivity, "Erro ao buscar vagas",
                    Toast.LENGTH_LONG).show()
            }
        })
    }
}