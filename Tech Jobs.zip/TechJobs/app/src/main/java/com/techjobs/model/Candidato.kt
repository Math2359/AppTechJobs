package com.techjobs.model

data class Candidato(
    val id: Int? = null,
    val email: String,
    val nome: String,
    var senha: String
)