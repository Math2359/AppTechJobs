package com.techjobs.helper

import android.content.Context
import android.content.SharedPreferences
import com.techjobs.model.UserCredentials

class SessionHelper (context: Context) {
    private var prefs: SharedPreferences = context.getSharedPreferences("Tech Jobs",
        Context.MODE_PRIVATE)

    companion object {
        const val ID = "id"
        const val PERFIL = "perfil"
    }

    fun salvarUserCredentials(userCredentials: UserCredentials) {
        val editor = prefs.edit()
        editor.putInt(ID, userCredentials.id)
        editor.putString(PERFIL, userCredentials.perfil)
        editor.apply()
    }

    fun obterUserCredentials(): UserCredentials {
        return UserCredentials(id = prefs.getInt(ID, 0), perfil = prefs.getString(PERFIL, null))
    }
}