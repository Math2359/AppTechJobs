package com.techjobs.model

data class UserCredentials(
    val id: Int,
    val perfil: String?
)
