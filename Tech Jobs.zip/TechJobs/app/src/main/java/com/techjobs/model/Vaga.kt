package com.techjobs.model

data class Vaga(
    val id: Int? = null,
    val empresa: Empresa,
    val cargo: String,
    val modelo: String,
    val nivel: String,
    val cep: String,
    val numero: String,
    val descricao: String,
    val salario: Double
)
