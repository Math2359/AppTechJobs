package com.techjobs

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.techjobs.model.Candidato
import com.techjobs.retrofit.RetrofitInitializer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroCandidatoActivity : AppCompatActivity() {
    private lateinit var voltarBtn: ImageView

    private lateinit var finalizarBtn: Button
    private lateinit var nomeInput: TextInputEditText
    private lateinit var emailInput: TextInputEditText
    private lateinit var senhaInput: TextInputEditText
    private lateinit var confirmarSenhaInput: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro_candidato)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        voltarBtn = findViewById<ImageView>(R.id.voltarBtn)
        voltarBtn.setOnClickListener {
            val intent: Intent = Intent(this, EscolhaPerfilCadastroActivity::class.java)
            startActivity(intent)
        }

        emailInput = findViewById<TextInputEditText>(R.id.inputEmail)
        nomeInput = findViewById<TextInputEditText>(R.id.inputNome)
        senhaInput = findViewById<TextInputEditText>(R.id.inputSenha)
        confirmarSenhaInput = findViewById<TextInputEditText>(R.id.inputConfirmarSenha)

        finalizarBtn = findViewById<Button>(R.id.finalizarBtn)
        finalizarBtn.setOnClickListener {
            val candidato: Candidato = Candidato(
                email = emailInput.text.toString(),
                nome = nomeInput.text.toString(),
                senha = senhaInput.text.toString())

            val call = RetrofitInitializer().candidatoService.cadastrarCandidato(candidato)
            call.enqueue(object: Callback<Void> {
                override fun onResponse(call: Call<Void>,
                                        response: Response<Void>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@CadastroCandidatoActivity,
                            "Cadastro realizado com sucesso",
                            Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<Void>, t: Throwable?) {
                    Toast.makeText(this@CadastroCandidatoActivity, "Erro ao realizar cadastro",
                        Toast.LENGTH_LONG).show()
                }
            })
        }
    }
}