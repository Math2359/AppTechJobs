package com.techjobs

import android.content.Intent
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.techjobs.helper.SessionHelper
import com.techjobs.model.EnumPerfil
import com.techjobs.model.Login
import com.techjobs.model.UserCredentials
import com.techjobs.retrofit.RetrofitInitializer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

const val textoSenha = "Esqueci minha senha"
const val textoCadastro = "Cadastre-se aqui"

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val underline = findViewById<TextView>(R.id.underline)
        val span = SpannableString(textoSenha)
        span.setSpan(UnderlineSpan(), 0, span.length, 0)
        underline.text = span

        val underline2 = findViewById<TextView>(R.id.underline2)
        val span2 = SpannableString(textoCadastro)
        span2.setSpan(UnderlineSpan(), 0, span2.length, 0)
        underline2.text = span2
        underline2.setOnClickListener {
            val intent: Intent = Intent(this, EscolhaPerfilCadastroActivity::class.java)
            startActivity(intent)
        }

        val inputEmail: TextInputEditText = findViewById<TextInputEditText>(R.id.inputEmail)
        val inputSenha: TextInputEditText = findViewById<TextInputEditText>(R.id.inputSenha)

        val button: Button = findViewById<Button>(R.id.finalizarBtn)
        button.setOnClickListener {
            val call = RetrofitInitializer().loginService.logar(Login(
                email = inputEmail.text.toString(),
                senha = inputSenha.text.toString()
            ))

            val intentCandidato: Intent = Intent(this, DashboardCandidatoActivity::class.java)
            val intentEmpresa: Intent = Intent(this, DashboardEmpresaActivity::class.java)

            call.enqueue(object: Callback<UserCredentials> {
                override fun onResponse(
                    call: Call<UserCredentials?>,
                    response: Response<UserCredentials>
                ) {
                    if (response.isSuccessful) {
                        val userCredentials: UserCredentials? = response.body()
                        if (userCredentials != null) {
                            SessionHelper(this@MainActivity).salvarUserCredentials(userCredentials)

                            Toast.makeText(this@MainActivity, "Login realizado com sucesso",
                                Toast.LENGTH_LONG).show()

                            if (userCredentials.perfil == EnumPerfil.Candidato.toString()) {
                                startActivity(intentCandidato)
                            }

                            if (userCredentials.perfil == EnumPerfil.Empresa.toString()) {
                                startActivity(intentEmpresa)
                            }
                        }
                    }
                }

                override fun onFailure(call: Call<UserCredentials?>, t: Throwable) {
                    Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_LONG).show()
                }
            })
        }
    }
}