package com.techjobs.model

enum class EnumPerfil {
    Candidato, Empresa
}