package com.techjobs.service

import com.techjobs.model.Candidato
import com.techjobs.model.Empresa
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

interface EmpresaService {
    @Headers("Content-Type: application/json")
    @POST("empresa")
    fun cadastrarEmpresa(@Body empresa: Empresa): Call<Void>
}