package com.techjobs.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.techjobs.CadastroCandidatoActivity
import com.techjobs.DashboardEmpresaActivity
import com.techjobs.R
import com.techjobs.model.Vaga
import com.techjobs.retrofit.RetrofitInitializer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VagasEmpresaAdapter(private var dataSet: Array<Vaga>, private val context: Context) :
    RecyclerView.Adapter<VagasEmpresaAdapter.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cargo: TextView
        val experiencia: TextView
        val salario: TextView
        val local: TextView
        val trash: ImageView

        init {
            cargo = view.findViewById(R.id.cargo)
            experiencia = view.findViewById(R.id.experiencia)
            salario = view.findViewById(R.id.salario)
            local = view.findViewById(R.id.local)
            trash = view.findViewById(R.id.delete)
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.objeto_lista_empresa, viewGroup, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.cargo.text = dataSet[position].cargo
        viewHolder.experiencia.text = dataSet[position].nivel
        viewHolder.salario.text = "R$ ${dataSet[position].salario}"
        viewHolder.local.text = "${dataSet[position].cep}, ${dataSet[position].numero} - ${dataSet[position].modelo}"
        viewHolder.trash.setOnClickListener {
            val call = RetrofitInitializer().vagaService.deletarVaga(dataSet[position].id?:0)
            call.enqueue(object: Callback<Void> {
                override fun onResponse(call: Call<Void>,
                                        response: Response<Void>) {
                    if (response.isSuccessful) {
                        Toast.makeText(context,
                            "Vaga deletada com sucesso",
                            Toast.LENGTH_LONG).show()
                        dataSet = dataSet.drop(position).toTypedArray()
                        this@VagasEmpresaAdapter.notifyItemRemoved(position)
                    }
                }

                override fun onFailure(call: Call<Void>, t: Throwable?) {
                    Toast.makeText(context, "Erro ao deletar vaga",
                        Toast.LENGTH_LONG).show()
                }
            })
        }
        viewHolder.trash.setImageResource(R.drawable.round_delete_24)
    }

    override fun getItemCount() = dataSet.size
}