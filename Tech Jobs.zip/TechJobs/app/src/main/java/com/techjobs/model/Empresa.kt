package com.techjobs.model

data class Empresa(
    val id: Int? = null,
    val email: String,
    val nome: String,
    val senha: String,
    val cnpj: String
)
