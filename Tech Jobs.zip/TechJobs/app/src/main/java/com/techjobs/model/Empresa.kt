package com.techjobs.model

data class Empresa(
    val id: Int? = null,
    val email: String? = null,
    val nome: String? = null,
    val senha: String? = null,
    val cnpj: String? = null
)
